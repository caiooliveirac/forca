--
-- PostgreSQL database dump
--

\restrict rONUJ5IQ2TKLiTTpWHFpHSAxSQxKiZPYafHma1rDPzDolwTCKZbaGxuK4toe0wF

-- Dumped from database version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.word_errors DROP CONSTRAINT IF EXISTS word_errors_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.player_stats DROP CONSTRAINT IF EXISTS player_stats_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.game_rounds DROP CONSTRAINT IF EXISTS game_rounds_user_id_fkey;
DROP TRIGGER IF EXISTS users_updated_at ON public.users;
DROP TRIGGER IF EXISTS player_stats_updated_at ON public.player_stats;
DROP INDEX IF EXISTS public.idx_word_errors_user;
DROP INDEX IF EXISTS public.idx_word_errors_review;
DROP INDEX IF EXISTS public.idx_rounds_user;
DROP INDEX IF EXISTS public.idx_rounds_played;
DROP INDEX IF EXISTS public.idx_rounds_cefr_level;
ALTER TABLE IF EXISTS ONLY public.word_errors DROP CONSTRAINT IF EXISTS word_errors_user_id_word_id_key;
ALTER TABLE IF EXISTS ONLY public.word_errors DROP CONSTRAINT IF EXISTS word_errors_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.player_stats DROP CONSTRAINT IF EXISTS player_stats_user_id_key;
ALTER TABLE IF EXISTS ONLY public.player_stats DROP CONSTRAINT IF EXISTS player_stats_pkey;
ALTER TABLE IF EXISTS ONLY public.game_rounds DROP CONSTRAINT IF EXISTS game_rounds_pkey;
DROP TABLE IF EXISTS public.word_errors;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.player_stats;
DROP TABLE IF EXISTS public.game_rounds;
DROP FUNCTION IF EXISTS public.update_updated_at();
DROP EXTENSION IF EXISTS pgcrypto;
-- *not* dropping schema, since initdb creates it
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: update_updated_at(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: game_rounds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.game_rounds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    word_id text NOT NULL,
    word text NOT NULL,
    won boolean NOT NULL,
    score integer DEFAULT 0,
    difficulty integer NOT NULL,
    wrong_guesses integer NOT NULL,
    time_seconds integer NOT NULL,
    hints_used jsonb DEFAULT '{}'::jsonb,
    used_partial_umlauts boolean DEFAULT false,
    combo_at_time integer DEFAULT 0,
    played_at timestamp with time zone DEFAULT now(),
    cefr_level text DEFAULT 'A1'::text,
    weighted_score integer DEFAULT 0,
    anti_spam_flag boolean DEFAULT false
);


--
-- Name: player_stats; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_stats (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    total_games integer DEFAULT 0,
    total_wins integer DEFAULT 0,
    total_points bigint DEFAULT 0,
    best_round_score integer DEFAULT 0,
    best_combo integer DEFAULT 0,
    current_combo integer DEFAULT 0,
    updated_at timestamp with time zone DEFAULT now(),
    competitive_points bigint DEFAULT 0,
    rating integer DEFAULT 1000,
    last_competitive_at timestamp with time zone
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    display_name text NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: word_errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.word_errors (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    word_id text NOT NULL,
    word text NOT NULL,
    times_seen integer DEFAULT 0,
    times_correct integer DEFAULT 0,
    times_wrong integer DEFAULT 0,
    last_seen_at timestamp with time zone DEFAULT now(),
    next_review_at timestamp with time zone,
    ease_factor real DEFAULT 2.5
);


--
-- Data for Name: game_rounds; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.game_rounds (id, user_id, word_id, word, won, score, difficulty, wrong_guesses, time_seconds, hints_used, used_partial_umlauts, combo_at_time, played_at, cefr_level, weighted_score, anti_spam_flag) FROM stdin;
ce22bfbd-2ce6-4941-805d-8fdd18d407ea	a22782fa-60fd-4e69-a643-6efd8a4ff451	w200	Frühling	t	384	5	7	48	{"beispiel": false, "buchstabe": false, "kategorie": true}	t	1	2026-02-22 23:55:19.885721+00	A1	0	f
55ad8573-e47a-4d97-8b99-a16eba938054	a22782fa-60fd-4e69-a643-6efd8a4ff451	w319	Ergebnis	t	227	3	7	27	{"beispiel": true, "buchstabe": true, "kategorie": true}	f	2	2026-02-22 23:56:08.65433+00	A1	0	f
96a9df70-419d-4021-a303-9e5a8cdd83e1	a22782fa-60fd-4e69-a643-6efd8a4ff451	w333	Überstunden	f	0	5	8	27	{"beispiel": false, "buchstabe": false, "kategorie": true}	f	0	2026-02-22 23:56:45.078921+00	A1	0	f
278133da-18dc-4a20-9cd5-c00ebb7086e1	a22782fa-60fd-4e69-a643-6efd8a4ff451	w127	wandern	t	252	3	7	36	{"beispiel": true, "buchstabe": false, "kategorie": true}	f	1	2026-02-22 23:57:31.786866+00	A1	0	f
8c0c284e-7d21-4b3b-bf57-927ce49e8c4c	a22782fa-60fd-4e69-a643-6efd8a4ff451	w287	möglich	t	479	3	3	17	{"beispiel": false, "buchstabe": false, "kategorie": true}	t	2	2026-02-22 23:57:55.413848+00	A1	0	f
af3d5482-6230-4a81-90fe-6721e0dc42e1	a22782fa-60fd-4e69-a643-6efd8a4ff451	b2-081	Genesung	f	0	3	8	25	{"beispiel": false, "buchstabe": false, "kategorie": false}	f	0	2026-02-23 02:04:51.165124+00	A1	0	f
cd06c3ea-8da3-4eab-b09a-aa9f97216b86	a22782fa-60fd-4e69-a643-6efd8a4ff451	c1-093	Nahrungskette	f	0	3	8	17	{"beispiel": false, "buchstabe": false, "kategorie": false}	f	0	2026-02-23 02:05:14.601216+00	A1	0	f
c79e5d06-ec33-46c5-be19-c90686d3f5de	a22782fa-60fd-4e69-a643-6efd8a4ff451	c1-111	Grundversorgung	f	0	4	8	113	{"beispiel": true, "buchstabe": false, "kategorie": true}	f	0	2026-02-23 04:42:27.521779+00	A1	0	f
e5d90db5-d7d3-41da-8684-057476222e66	a22782fa-60fd-4e69-a643-6efd8a4ff451	a1-109	Sport	f	0	1	8	22	{"beispiel": true, "buchstabe": false, "kategorie": true}	f	0	2026-02-23 04:43:10.724776+00	A1	0	f
\.


--
-- Data for Name: player_stats; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.player_stats (id, user_id, total_games, total_wins, total_points, best_round_score, best_combo, current_combo, updated_at, competitive_points, rating, last_competitive_at) FROM stdin;
4e400bc2-79fc-4e3b-8b5b-ca27d230e341	a22782fa-60fd-4e69-a643-6efd8a4ff451	9	4	1342	479	2	0	2026-02-23 04:43:10.724776+00	0	1000	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, email, password_hash, display_name, created_at, updated_at) FROM stdin;
a22782fa-60fd-4e69-a643-6efd8a4ff451	caio.olive94@gmail.com	$2b$12$IRu19ys.oH758RjlgYzbbumipHxh/AhjylzMs5lURKtXiwikEnj9a	Caio	2026-02-22 23:54:45.861289+00	2026-02-22 23:54:45.861289+00
\.


--
-- Data for Name: word_errors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.word_errors (id, user_id, word_id, word, times_seen, times_correct, times_wrong, last_seen_at, next_review_at, ease_factor) FROM stdin;
ee912ed8-a30b-454c-87f1-84a6a815f2e6	a22782fa-60fd-4e69-a643-6efd8a4ff451	w200	Frühling	1	1	0	2026-02-22 23:55:19.885721+00	\N	2.5
446cf084-c77f-4bba-9243-4e4bf1dc608e	a22782fa-60fd-4e69-a643-6efd8a4ff451	w319	Ergebnis	1	1	0	2026-02-22 23:56:08.65433+00	\N	2.5
6b02f9e9-c1e0-47bf-95b0-8f2a41578f88	a22782fa-60fd-4e69-a643-6efd8a4ff451	w333	Überstunden	1	0	1	2026-02-22 23:56:45.078921+00	\N	2.5
d4087084-968a-4477-9c1f-afc45aff584a	a22782fa-60fd-4e69-a643-6efd8a4ff451	w127	wandern	1	1	0	2026-02-22 23:57:31.786866+00	\N	2.5
ba6e037a-b10f-4f55-bd37-cd92dfa5de47	a22782fa-60fd-4e69-a643-6efd8a4ff451	w287	möglich	1	1	0	2026-02-22 23:57:55.413848+00	\N	2.5
a349e9e1-5f9b-4a94-981a-f610c95a05de	a22782fa-60fd-4e69-a643-6efd8a4ff451	b2-081	Genesung	1	0	1	2026-02-23 02:04:51.165124+00	\N	2.5
cc1687c3-773d-46dc-b313-28a3a2bdc795	a22782fa-60fd-4e69-a643-6efd8a4ff451	c1-093	Nahrungskette	1	0	1	2026-02-23 02:05:14.601216+00	\N	2.5
07d5a39b-23d0-4b23-8f34-6ed9ec8ccf7b	a22782fa-60fd-4e69-a643-6efd8a4ff451	c1-111	Grundversorgung	1	0	1	2026-02-23 04:42:27.521779+00	\N	2.5
ca6d47ac-f67d-44cc-b03a-4c7d338de6d3	a22782fa-60fd-4e69-a643-6efd8a4ff451	a1-109	Sport	1	0	1	2026-02-23 04:43:10.724776+00	\N	2.5
\.


--
-- Name: game_rounds game_rounds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_rounds
    ADD CONSTRAINT game_rounds_pkey PRIMARY KEY (id);


--
-- Name: player_stats player_stats_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_pkey PRIMARY KEY (id);


--
-- Name: player_stats player_stats_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_user_id_key UNIQUE (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: word_errors word_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.word_errors
    ADD CONSTRAINT word_errors_pkey PRIMARY KEY (id);


--
-- Name: word_errors word_errors_user_id_word_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.word_errors
    ADD CONSTRAINT word_errors_user_id_word_id_key UNIQUE (user_id, word_id);


--
-- Name: idx_rounds_cefr_level; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_cefr_level ON public.game_rounds USING btree (cefr_level);


--
-- Name: idx_rounds_played; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_played ON public.game_rounds USING btree (played_at DESC);


--
-- Name: idx_rounds_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rounds_user ON public.game_rounds USING btree (user_id);


--
-- Name: idx_word_errors_review; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_word_errors_review ON public.word_errors USING btree (next_review_at);


--
-- Name: idx_word_errors_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_word_errors_user ON public.word_errors USING btree (user_id);


--
-- Name: player_stats player_stats_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER player_stats_updated_at BEFORE UPDATE ON public.player_stats FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: users users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at();


--
-- Name: game_rounds game_rounds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.game_rounds
    ADD CONSTRAINT game_rounds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: player_stats player_stats_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_stats
    ADD CONSTRAINT player_stats_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: word_errors word_errors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.word_errors
    ADD CONSTRAINT word_errors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict rONUJ5IQ2TKLiTTpWHFpHSAxSQxKiZPYafHma1rDPzDolwTCKZbaGxuK4toe0wF

